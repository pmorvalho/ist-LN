#!/bin/bash

################### Tradutores de tradução ################
#
# Compila e gera a versão gráfica do transdutor que traduz letra a letra
fstcompile --isymbols=syms.txt --osymbols=syms.txt arab2roman.txt | fstarcsort > arab2roman.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait arab2roman.fst | dot -Tpng  > arab2roman.png
